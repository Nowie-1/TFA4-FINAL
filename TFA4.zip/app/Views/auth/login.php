<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php helper('form'); ?>

<div class="page-head">
    <h1>Log in</h1>
    <p class="sub">Sign in with your staff account to manage customers and users.</p>
</div>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-error" role="alert"><?= esc(session()->getFlashdata('error')) ?></div>
<?php endif; ?>

<?= $this->include('partials/flash') ?>

<section class="panel">
    <div class="panel-head"><h2>Staff login</h2></div>

    <?= form_open(site_url('login'), ['class' => 'form', 'novalidate' => 'novalidate']) ?>

        <div class="field <?= validation_show_error('username') ? 'has-error' : '' ?>">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" maxlength="50" autocomplete="username" autofocus
                   value="<?= esc(old('username')) ?>">
            <?= validation_show_error('username') ?>
        </div>

        <div class="field <?= validation_show_error('password') ? 'has-error' : '' ?>">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" autocomplete="current-password">
            <?= validation_show_error('password') ?>
        </div>

        <div class="actions">
            <button type="submit" class="btn btn-primary">Log in</button>
        </div>

    <?= form_close() ?>
</section>

<?= $this->endSection() ?>
