<?php
helper(['url', 'form']);

$nav = [
    [
        'path'  => '',
        'label' => 'Home',
        'icon'  => '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1z"/>',
    ],
    [
        'path'  => 'about',
        'label' => 'About',
        'icon'  => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    ],
    [
        'path'  => 'customers',
        'label' => 'Customers',
        'icon'  => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.3c2 .8 3.5 2.7 3.5 5.7"/>',
    ],
    [
        'path'  => 'users',
        'label' => 'Users',
        'icon'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.5-1.5 1.7-2 3-2s2.5.5 3 2M15 10h3M15 13h3"/>',
    ],
];

$current = trim(uri_string(), '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title ?? "Noe's Shop") ?> | Noe's Shop</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700&family=Hanken+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/till.css') ?>">
</head>
<body>
    <div class="shell">

        <aside class="sidebar">
            <header class="masthead">
                <p class="shop">Noe's Shop</p>
                <p class="tagline">A website for Noe to track her ecommerce's website.</p>
            </header>

            <nav aria-label="Main">
                <ul class="nav">
                    <?php foreach ($nav as $item): ?>
                        <li>
                            <a href="<?= site_url($item['path']) ?>"
                               <?= $current === $item['path'] ? 'aria-current="page"' : '' ?>>
                                <svg viewBox="0 0 24 24" aria-hidden="true"><?= $item['icon'] ?></svg>
                                <span><?= esc($item['label']) ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>

            <div class="sidebar-foot">
                <?php if (session()->get('isLoggedIn')): ?>
                    <p>Signed in as <strong><?= esc(session()->get('fullName')) ?></strong></p>
                    <?= form_open(site_url('logout')) ?>
                        <button type="submit" class="btn btn-ghost">Log out</button>
                    <?= form_close() ?>
                <?php else: ?>
                    <a class="btn btn-ghost" href="<?= site_url('login') ?>">Log in</a>
                <?php endif; ?>
            </div>
        </aside>

        <main class="content">
            <?= $this->renderSection('content') ?>
        </main>

    </div>
</body>
</html>
