<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<?php helper('avatar'); ?>

<div class="page-head page-head-row">
    <div>
        <h1>User accounts</h1>
        <p class="sub">The staff who can sign in to Noe's Shop.</p>
    </div>
    <a class="btn btn-primary" href="<?= site_url('users/new') ?>">+ New user</a>
</div>

<?= $this->include('partials/flash') ?>

<?php if (empty($users)): ?>
    <p>No staff accounts yet. <a class="link" href="<?= site_url('users/new') ?>">Add the first user</a> to see them listed here.</p>
<?php else: ?>

    <section class="stats" aria-label="Summary">
        <div class="stat">
            <p class="stat-num"><?= count($users) ?></p>
            <p class="stat-label">Staff on file</p>
        </div>
    </section>

    <section class="panel">
        <div class="panel-head"><h2>All staff</h2></div>
        <div class="scroll">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Username</th>
                        <th scope="col">Full name</th>
                        <th scope="col">Member since</th>
                        <th scope="col"><span class="sr-only">Actions</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $i => $user): ?>
                        <tr>
                            <td><?= esc($user['username']) ?></td>
                            <td>
                                <div class="person">
                                    <img class="avatar-img" src="<?= esc(avatar_url($user['avatar'] ?? null)) ?>"
                                         alt="Profile picture of <?= esc($user['full_name']) ?>" width="36" height="36">
                                    <span><?= esc($user['full_name']) ?></span>
                                </div>
                            </td>
                            <td><?= esc(date('M j, Y', strtotime($user['created_at']))) ?></td>
                            <td><a class="link" href="<?= site_url('users/' . $user['id'] . '/edit') ?>">Edit</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>

<?= $this->endSection() ?>
