<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php
helper(['form', 'avatar']);
$isEdit = ! empty($user['id']);
?>

<div class="page-head">
    <h1><?= esc($heading) ?></h1>
    <p class="sub">Fields marked <span class="req">*</span> are required.</p>
</div>

<?= $this->include('partials/flash') ?>

<section class="panel">
    <div class="panel-head"><h2>Account details</h2></div>

    <?php if ($isEdit): ?>
        <?= form_open_multipart($action, ['class' => 'form', 'novalidate' => 'novalidate']) ?>
    <?php else: ?>
        <?= form_open($action, ['class' => 'form', 'novalidate' => 'novalidate']) ?>
    <?php endif; ?>

        <div class="field <?= validation_show_error('username') ? 'has-error' : '' ?>">
            <label for="username">Username <span class="req">*</span></label>
            <input type="text" id="username" name="username" maxlength="50" autocomplete="off"
                   value="<?= esc(old('username', $user['username'])) ?>">
            <?= validation_show_error('username') ?>
        </div>

        <div class="field <?= validation_show_error('full_name') ? 'has-error' : '' ?>">
            <label for="full_name">Full name <span class="req">*</span></label>
            <input type="text" id="full_name" name="full_name" maxlength="100"
                   value="<?= esc(old('full_name', $user['full_name'])) ?>">
            <?= validation_show_error('full_name') ?>
        </div>

        <div class="field <?= validation_show_error('password') ? 'has-error' : '' ?>">
            <label for="password">Password <?php if (! $isEdit): ?><span class="req">*</span><?php endif; ?></label>
            <input type="password" id="password" name="password" autocomplete="new-password">
            <?php if ($isEdit): ?>
                <p class="hint">Leave empty to keep the current password.</p>
            <?php else: ?>
                <p class="hint">At least 8 characters.</p>
            <?php endif; ?>
            <?= validation_show_error('password') ?>
        </div>

        <?php if ($isEdit): ?>
            <div class="field <?= validation_show_error('avatar') ? 'has-error' : '' ?>">
                <label for="avatar">Profile picture</label>
                <div class="avatar-edit">
                    <img class="avatar-img avatar-img-lg"
                         src="<?= esc(avatar_url($user['avatar'] ?? null)) ?>"
                         alt="Current profile picture of <?= esc($user['full_name']) ?>">
                    <div>
                        <input type="file" id="avatar" name="avatar" accept="image/jpeg,image/png">
                        <p class="hint">JPG or PNG, up to 2MB. Leave empty to keep the current picture.</p>
                    </div>
                </div>
                <?= validation_show_error('avatar') ?>
            </div>
        <?php endif; ?>

        <div class="actions">
            <button type="submit" class="btn btn-primary">Save user</button>
            <a class="btn btn-ghost" href="<?= site_url('users') ?>">Cancel</a>
        </div>

    <?= form_close() ?>
</section>

<?= $this->endSection() ?>
