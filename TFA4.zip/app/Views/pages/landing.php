<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="page-head">
    <h1>Welcome back, Noe</h1>
    <p class="sub">This is where you keep an eye on the people who shop at and work for your store.</p>
</div>

<div class="tiles">
    <a class="tile tile-primary" href="<?= site_url('customers') ?>">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.3c2 .8 3.5 2.7 3.5 5.7"/></svg>
        <h2>Customers</h2>
        <p>See who has shopped with you, with their email and phone number.</p>
    </a>

    <a class="tile" href="<?= site_url('users') ?>">
        <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.5-1.5 1.7-2 3-2s2.5.5 3 2M15 10h3M15 13h3"/></svg>
        <h2>Users</h2>
        <p>See the staff who work at Noe's Shop, and when each one joined.</p>
    </a>

    <a class="tile" href="<?= site_url('about') ?>">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>
        <h2>About the Company Products</h2>
        <p>Check for product availability.</p>
    </a>
</div>

<?= $this->endSection() ?>
