<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="page-head">
    <h1>About the Company</h1>
    <p class="sub">
        An ecommerce that aims to give the best products for Noe's customers.
    </p>
</div>

<section class="panel">
    <div class="panel-head"><h2>Our Product Availability</h2></div>
    <dl class="facts">
        <div><dt>Jasmine Perfume</dt><dd>400/1000</dd></div>
        <div><dt>Petunia Makeup Kit</dt><dd>300/500</dd></div>
        <div><dt>Rose Skincare</dt><dd>100/500</dd></div>
        <div><dt>Lily Haircare</dt><dd>400/500</dd></div>
    </dl>
</section>

<?= $this->endSection() ?>
