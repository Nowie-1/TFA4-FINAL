<?php helper('form'); ?>
<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-ok" role="status"><?= esc(session()->getFlashdata('success')) ?></div>
<?php endif; ?>

<?php if (! empty(validation_errors())): ?>
    <div class="alert alert-error" role="alert">Please fix the highlighted fields and try again.</div>
<?php endif; ?>
