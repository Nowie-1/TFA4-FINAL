<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="page-head page-head-row">
    <div>
        <h1>Customer accounts</h1>
        <p class="sub">Everyone who has shopped at Noe's Shop, with their contact details.</p>
    </div>
    <a class="btn btn-primary" href="<?= site_url('customers/new') ?>">+ New customer</a>
</div>

<?= $this->include('partials/flash') ?>

<?php if (empty($customers)): ?>
    <p>No customers yet. <a class="link" href="<?= site_url('customers/new') ?>">Add the first customer</a> to see them listed here.</p>
<?php else: ?>
    <?php
    $withPhone = count(array_filter($customers, fn ($c) => ! empty($c['phone'])));
    ?>

    <section class="stats" aria-label="Summary">
        <div class="stat">
            <p class="stat-num"><?= count($customers) ?></p>
            <p class="stat-label">Customers on file</p>
        </div>
        <div class="stat">
            <p class="stat-num"><?= $withPhone ?></p>
            <p class="stat-label">With a phone number</p>
        </div>
    </section>

    <section class="panel">
        <div class="panel-head"><h2>All customers</h2></div>
        <div class="scroll">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Full name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col"><span class="sr-only">Actions</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($customers as $i => $customer): ?>
                        <?php
                        $parts    = explode(' ', trim($customer['full_name']));
                        $initials = strtoupper(substr($parts[0], 0, 1) . substr(end($parts), 0, 1));
                        ?>
                        <tr>
                            <td>
                                <div class="person">
                                    <span class="avatar av-<?= $i % 5 ?>" aria-hidden="true"><?= esc($initials) ?></span>
                                    <span><?= esc($customer['full_name']) ?></span>
                                </div>
                            </td>
                            <td><?= esc($customer['email']) ?></td>
                            <td><?= esc($customer['phone']) ?></td>
                            <td><a class="link" href="<?= site_url('customers/' . $customer['id'] . '/edit') ?>">Edit</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>

<?= $this->endSection() ?>
