<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php helper('form'); ?>

<div class="page-head">
    <h1><?= esc($heading) ?></h1>
    <p class="sub">Fields marked <span class="req">*</span> are required.</p>
</div>

<?= $this->include('partials/flash') ?>

<section class="panel">
    <div class="panel-head"><h2>Customer details</h2></div>

    <?= form_open($action, ['class' => 'form', 'novalidate' => 'novalidate']) ?>

        <div class="field <?= validation_show_error('full_name') ? 'has-error' : '' ?>">
            <label for="full_name">Full name <span class="req">*</span></label>
            <input type="text" id="full_name" name="full_name" maxlength="100"
                   value="<?= esc(old('full_name', $customer['full_name'])) ?>">
            <?= validation_show_error('full_name') ?>
        </div>

        <div class="field <?= validation_show_error('email') ? 'has-error' : '' ?>">
            <label for="email">Email <span class="req">*</span></label>
            <input type="email" id="email" name="email" maxlength="100"
                   value="<?= esc(old('email', $customer['email'])) ?>">
            <?= validation_show_error('email') ?>
        </div>

        <div class="field <?= validation_show_error('phone') ? 'has-error' : '' ?>">
            <label for="phone">Phone</label>
            <input type="text" id="phone" name="phone" maxlength="20"
                   value="<?= esc(old('phone', $customer['phone'] ?? '')) ?>">
            <?= validation_show_error('phone') ?>
        </div>

        <div class="actions">
            <button type="submit" class="btn btn-primary">Save customer</button>
            <a class="btn btn-ghost" href="<?= site_url('customers') ?>">Cancel</a>
        </div>

    <?= form_close() ?>
</section>

<?= $this->endSection() ?>
