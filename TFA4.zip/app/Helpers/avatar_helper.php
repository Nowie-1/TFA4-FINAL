<?php

if (! function_exists('avatar_url')) {
    /**
     * Public URL of a user's prepared avatar, or the placeholder image
     * when the user has none (or the file is missing on disk).
     */
    function avatar_url(?string $filename): string
    {
        if (! empty($filename)) {
            $filename = basename($filename);

            if (is_file(FCPATH . 'uploads/avatars/' . $filename)) {
                return base_url('uploads/avatars/' . $filename);
            }
        }

        return base_url('images/avatar-placeholder.svg');
    }
}
