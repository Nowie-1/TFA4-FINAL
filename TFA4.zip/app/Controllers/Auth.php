<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\HTTP\RedirectResponse;

class Auth extends BaseController
{
    /** Show the login form (logged-in users go straight to the customers page). */
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to(site_url('customers'));
        }

        return view('auth/login', ['title' => 'Log in']);
    }

    /** Check the username and password, then start the session. */
    public function attempt(): RedirectResponse
    {
        $rules = [
            'username' => 'trim|required',
            'password' => 'required',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput();
        }

        $username = trim((string) $this->request->getPost('username'));
        $password = (string) $this->request->getPost('password');

        $user = (new UserModel())->where('username', $username)->first();

        // One generic message so the form never reveals which part was wrong.
        if ($user === null || empty($user['password']) || ! password_verify($password, $user['password'])) {
            return redirect()->back()->withInput()->with('error', 'Invalid username or password.');
        }

        // New session id after login prevents session fixation.
        session()->regenerate();
        session()->set([
            'isLoggedIn' => true,
            'userId'     => $user['id'],
            'username'   => $user['username'],
            'fullName'   => $user['full_name'],
        ]);

        return redirect()->to(site_url('customers'))->with('success', 'Welcome back, ' . $user['full_name'] . '!');
    }

    /** Destroy the session and return to the login page. */
    public function logout(): RedirectResponse
    {
        session()->destroy();

        return redirect()->to(site_url('login'));
    }
}
