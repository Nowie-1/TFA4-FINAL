<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\RedirectResponse;
use CodeIgniter\HTTP\Files\UploadedFile;

class Users extends BaseController
{
    /** Folder (inside /public) where prepared avatars are stored. */
    private const AVATAR_DIR = 'uploads/avatars/';

    /** Avatar thumbnails are cropped to a square of this size (px). */
    private const AVATAR_SIZE = 200;

    public function index(): string
    {
        $userModel = new UserModel();
        $users     = $userModel->orderBy('full_name', 'ASC')->findAll();

        return view('users/index', [
            'title' => 'User accounts',
            'users' => $users,
        ]);
    }

    /** Show the empty "New User" form. */
    public function new(): string
    {
        return view('users/form', [
            'title'   => 'New user',
            'heading' => 'New user',
            'action'  => site_url('users'),
            'user'    => ['id' => null, 'username' => '', 'full_name' => '', 'avatar' => null],
        ]);
    }

    /** Validate and insert a new user. */
    public function create(): RedirectResponse
    {
        $rules = [
            'username' => [
                'label'  => 'Username',
                'rules'  => 'trim|required|alpha_dash|min_length[3]|max_length[50]|is_unique[users.username]',
                'errors' => ['is_unique' => 'That username is already taken.'],
            ],
            'full_name' => [
                'label' => 'Full name',
                'rules' => 'trim|required|min_length[2]|max_length[100]',
            ],
            'password' => [
                'label' => 'Password',
                'rules' => 'required|min_length[8]|max_length[72]',
            ],
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput();
        }

        (new UserModel())->insert([
            'username'   => trim((string) $this->request->getPost('username')),
            'full_name'  => trim((string) $this->request->getPost('full_name')),
            'password'   => password_hash((string) $this->request->getPost('password'), PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(site_url('users'))->with('success', 'User added. You can upload a profile picture from the edit page.');
    }

    /** Show the edit form pre-filled with the existing record. */
    public function edit(int $id): string
    {
        $user = $this->findOr404($id);

        return view('users/form', [
            'title'   => 'Edit user',
            'heading' => 'Edit user',
            'action'  => site_url('users/' . $id),
            'user'    => $user,
        ]);
    }

    /** Validate and update an existing user, including the optional avatar. */
    public function update(int $id): RedirectResponse
    {
        $user = $this->findOr404($id);

        $rules = [
            'username' => [
                'label'  => 'Username',
                // Ignore this user's own row so keeping the same username is allowed.
                'rules'  => "trim|required|alpha_dash|min_length[3]|max_length[50]|is_unique[users.username,id,{$id}]",
                'errors' => ['is_unique' => 'That username is already taken.'],
            ],
            'full_name' => [
                'label' => 'Full name',
                'rules' => 'trim|required|min_length[2]|max_length[100]',
            ],
        ];

        // The password is optional on edit: only validate it when a new one was typed.
        $newPassword = (string) $this->request->getPost('password');

        if ($newPassword !== '') {
            $rules['password'] = [
                'label' => 'Password',
                'rules' => 'min_length[8]|max_length[72]',
            ];
        }

        // The avatar is optional: only validate it when a file was actually chosen.
        $file      = $this->request->getFile('avatar');
        $hasUpload = $file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE;

        if ($hasUpload) {
            $rules['avatar'] = [
                'label'  => 'Profile picture',
                'rules'  => 'uploaded[avatar]|is_image[avatar]|mime_in[avatar,image/jpg,image/jpeg,image/png]'
                          . '|ext_in[avatar,jpg,jpeg,png]|max_size[avatar,2048]',
                'errors' => [
                    'uploaded'  => 'The upload failed. Please try again with a file under 2MB.',
                    'is_image'  => 'The profile picture must be a valid image.',
                    'mime_in'   => 'The profile picture must be a JPG or PNG.',
                    'ext_in'    => 'The profile picture must be a JPG or PNG.',
                    'max_size'  => 'The profile picture must be 2MB or smaller.',
                ],
            ];
        }

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput();
        }

        $data = [
            'username'  => trim((string) $this->request->getPost('username')),
            'full_name' => trim((string) $this->request->getPost('full_name')),
        ];

        if ($newPassword !== '') {
            $data['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
        }

        if ($hasUpload) {
            try {
                $data['avatar'] = $this->storeAvatar($file);
            } catch (\Throwable $e) {
                log_message('error', 'Avatar processing failed: ' . $e->getMessage());

                return redirect()->back()->withInput()
                    ->with('_ci_validation_errors', ['avatar' => 'The image could not be processed. Try a different file.']);
            }
        }

        (new UserModel())->update($id, $data);

        // Remove the previous avatar file only after the new one is saved.
        if ($hasUpload && ! empty($user['avatar'])) {
            $this->deleteAvatarFile($user['avatar']);
        }

        return redirect()->to(site_url('users'))->with('success', 'User updated.');
    }

    /**
     * Resize/crop the upload to a square thumbnail, store it in the public
     * uploads folder under a random name, and return that filename.
     */
    private function storeAvatar(UploadedFile $file): string
    {
        $dir = FCPATH . self::AVATAR_DIR;

        if (! is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        // Random name + extension from the real MIME type (never the client's filename).
        $filename = $file->getRandomName();

        service('image')
            ->withFile($file->getRealPath())
            ->fit(self::AVATAR_SIZE, self::AVATAR_SIZE, 'center')
            ->save($dir . $filename, 90);

        return $filename;
    }

    private function deleteAvatarFile(string $filename): void
    {
        // basename() guards against path tricks in the stored value.
        $path = FCPATH . self::AVATAR_DIR . basename($filename);

        if (is_file($path)) {
            @unlink($path);
        }
    }

    private function findOr404(int $id): array
    {
        $user = (new UserModel())->find($id);

        if ($user === null) {
            throw PageNotFoundException::forPageNotFound('User not found.');
        }

        return $user;
    }
}
