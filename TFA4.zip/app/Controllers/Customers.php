<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\RedirectResponse;

class Customers extends BaseController
{
    /**
     * Validation rules shared by the create and update actions.
     */
    private array $rules = [
        'full_name' => [
            'label' => 'Full name',
            'rules' => 'trim|required|min_length[2]|max_length[100]',
        ],
        'email' => [
            'label' => 'Email',
            'rules' => 'trim|required|valid_email|max_length[100]',
        ],
        'phone' => [
            'label' => 'Phone',
            'rules' => 'trim|permit_empty|max_length[20]|regex_match[/^[0-9+\-\s()]+$/]',
            'errors' => ['regex_match' => 'Phone may only contain digits, spaces, +, -, and parentheses.'],
        ],
    ];

    public function index(): string
    {
        $customerModel = new CustomerModel();
        $customers     = $customerModel->orderBy('full_name', 'ASC')->findAll();

        return view('customers/index', [
            'title'     => 'Customer accounts',
            'customers' => $customers,
        ]);
    }

    /** Show the empty "New Customer" form. */
    public function new(): string
    {
        return view('customers/form', [
            'title'    => 'New customer',
            'heading'  => 'New customer',
            'action'   => site_url('customers'),
            'customer' => ['full_name' => '', 'email' => '', 'phone' => ''],
        ]);
    }

    /** Validate and insert a new customer. */
    public function create(): RedirectResponse
    {
        if (! $this->validate($this->rules)) {
            return redirect()->back()->withInput();
        }

        (new CustomerModel())->insert([
            'full_name'  => trim((string) $this->request->getPost('full_name')),
            'email'      => trim((string) $this->request->getPost('email')),
            'phone'      => trim((string) $this->request->getPost('phone')) ?: null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(site_url('customers'))->with('success', 'Customer added.');
    }

    /** Show the edit form pre-filled with the existing record. */
    public function edit(int $id): string
    {
        $customer = $this->findOr404($id);

        return view('customers/form', [
            'title'    => 'Edit customer',
            'heading'  => 'Edit customer',
            'action'   => site_url('customers/' . $id),
            'customer' => $customer,
        ]);
    }

    /** Validate and update an existing customer. */
    public function update(int $id): RedirectResponse
    {
        $this->findOr404($id);

        if (! $this->validate($this->rules)) {
            return redirect()->back()->withInput();
        }

        (new CustomerModel())->update($id, [
            'full_name' => trim((string) $this->request->getPost('full_name')),
            'email'     => trim((string) $this->request->getPost('email')),
            'phone'     => trim((string) $this->request->getPost('phone')) ?: null,
        ]);

        return redirect()->to(site_url('customers'))->with('success', 'Customer updated.');
    }

    private function findOr404(int $id): array
    {
        $customer = (new CustomerModel())->find($id);

        if ($customer === null) {
            throw PageNotFoundException::forPageNotFound('Customer not found.');
        }

        return $customer;
    }
}
