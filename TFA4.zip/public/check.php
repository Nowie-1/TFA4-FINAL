<?php

header('Content-Type: text/plain; charset=utf-8');

$root = dirname(__DIR__);

echo "PHP version: " . PHP_VERSION . "\n";
foreach (['mbstring', 'json', 'intl'] as $ext) {
    echo $ext . ': ' . (extension_loaded($ext) ? 'yes' : 'NO') . "\n";
}
echo "Site folder: $root\n\n";

$must = [
    '.htaccess',
    'public/index.php',
    'public/.htaccess',
    'public/css/till.css',
    'app/Config/Paths.php',
    'app/Config/Routes.php',
    'app/Controllers/Pages.php',
    'app/Controllers/Customers.php',
    'app/Controllers/Users.php',
    'app/Views/layouts/main.php',
    'app/Views/errors/html/production.php',
    'app/Views/errors/html/error_404.php',
    'app/Views/errors/html/error_exception.php',
    'vendor/autoload.php',
    'vendor/composer/autoload_static.php',
    'vendor/codeigniter4/framework/system/bootstrap.php',
    'vendor/codeigniter4/framework/system/CodeIgniter.php',
];

foreach ($must as $file) {
    echo (is_file($root . '/' . $file) ? 'OK       ' : 'MISSING  ') . $file . "\n";
}

$count = 0;
$dir = $root . '/vendor/codeigniter4/framework/system';
if (is_dir($dir)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile()) {
            $count++;
        }
    }
}
echo "\nFramework files uploaded: $count (should be 572)\n";
echo 'writable folder is writable: ' . (is_writable($root . '/writable') ? 'yes' : 'NO') . "\n";
