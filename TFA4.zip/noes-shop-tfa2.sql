CREATE DATABASE IF NOT EXISTS noes_shop;
USE noes_shop;

CREATE TABLE customers (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    full_name  VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL,
    phone      VARCHAR(20),
    created_at DATETIME NOT NULL
);

CREATE TABLE users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(50) NOT NULL UNIQUE,
    full_name  VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL
);

INSERT INTO customers (full_name, email, phone, created_at) VALUES
    ('Jamie Noelle Flores',     'jamief@gmail.com',      '09123456788', '2026-01-14 09:20:00'),
    ('Vladimir Jedric Vasquez', 'vladjed@gmail.com',     '09123456789', '2026-02-03 13:05:00'),
    ('Karol Lerdin',            'lerdinkarol@gmail.com', '09123456781', '2026-02-20 16:40:00'),
    ('Vhin Miranda',            'mvhin@gmail.com',       '09123456782', '2026-03-11 10:15:00'),
    ('Sidfrey Santos',          'itssidfrey@gmail.com',  '09123456783', '2026-04-02 18:30:00');

INSERT INTO users (username, full_name, created_at) VALUES
    ('noe',    'Noelle Reyes',  '2026-01-02 08:00:00'),
    ('mochi',  'Mochi Bunbun',  '2026-01-05 08:30:00'),
    ('pandan', 'Pandan Wafell', '2026-01-10 09:00:00'),
    ('ube',    'Ube Halayah',   '2026-01-10 09:15:00'),
    ('sesame', 'Sesame Seedz',  '2026-01-15 09:45:00');
